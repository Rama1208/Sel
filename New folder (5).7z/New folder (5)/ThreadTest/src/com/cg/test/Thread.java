package com.cg.test;

public class Thread {

	public static void main(String[] args) throws InterruptedException {
		for(int i=0;i<15;i++) {
			java.lang.Thread.sleep(1000);
			System.out.println("Rama");
		}
	
	}

}
