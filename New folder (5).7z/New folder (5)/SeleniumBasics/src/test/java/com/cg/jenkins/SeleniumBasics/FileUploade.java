package com.cg.jenkins.SeleniumBasics;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUploade {

WebDriver driver;
	
	
	@Before
	public void setUp() throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}

	@Test
	public void uploadFile() throws InterruptedException {
		String filename = "D:\\UI CLASSES\\DAY 3\\BootStrap Example";
		File file = new File(filename);
		String path = file.getAbsolutePath();
		driver.get("http://the-internet.herokuapp.com/upload");
		driver.findElement(By.id("file-upload")).sendKeys(path);
		driver.findElement(By.id("file-submit")).click();
		String text = driver.findElement(By.id("uploaded-files")).getText();
		System.out.println(text + "...");
		assertThat(text, is(equalTo(file.getName())));
		
	}

}
