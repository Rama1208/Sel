package com.cg.jenkins.SeleniumBasics;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageTest {

	WebDriver driver;
	@Before
	public void setUp() throws Exception{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@After
	public void tearDown() throws Exception{
		driver.quit();
	}
	@Test
	public void test() {
		int counter=0;
		driver.get("https://www.shutterstock.com/search/disposable");
		 List<WebElement> listImages=driver.findElements(By.tagName("img"));
	        System.out.println("No. of Images: "+listImages.size());
	        for(WebElement image:listImages)
	        {
	            if(image.isDisplayed())
	            {
	                counter++;
	                System.out.println(image.getAttribute("src"));
	            }
	        }
	        System.out.println("No. of total displable images: "+counter);
		
	}
}
