package com.cg.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginUtil {
	
	
	public WebDriver intializeDriver(String name) {
		if(name.equals("chrome")) {
	
		System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		return driver;
		}return null;
	}
}
