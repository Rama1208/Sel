package com.capg.step;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.PageFactory;

import com.capg.pojo.LoginPOMBeans;
import com.cg.util.LoginUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginTest {
	
	private WebDriver driver;
	private LoginPOMBeans pageBean;
	
	@Before
	public void Initialization() {
		
		
		
		
		LoginUtil du=new LoginUtil();
		driver=du.intializeDriver("chrome");
		
		pageBean=new LoginPOMBeans();
		PageFactory.initElements(driver, pageBean);
		
		
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
	
	@Test
	public void test() throws Throwable{
		to_register_to_github_account();
		 valid_username();
		 valid_password();
		 create_new_account();
		 
		 
	}
	
	@Given("^to register to github account$")
	public void to_register_to_github_account() throws Throwable {
	  driver.get("D:\\RAMA_BDD\\LoginForm\\WebContent\\login.html");
	  
	}

	
	@When("^valid username$")
	public void valid_username() throws Throwable {
	  pageBean.setName("rama");
	  
	  
	
	 /* Alert alert=driver.switchTo().alert();
	  alert.getText();
	  alert.accept();*/
	  
	
	}

	
	@When("^valid password$")
	public void valid_password() throws Throwable {
		pageBean.setPass("1234");
	   
	}

	
	@Then("^create new account$")
	public void create_new_account() throws Throwable {
	 
		pageBean.submit();
	}



}
