package com.capg.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPOMBeans {
	
	@FindBy(how=How.ID,id="username")
	private WebElement name;
	
	@FindBy(how=How.ID,id="password")
	private WebElement pass;
	
	@FindBy(how=How.LINK_TEXT,linkText="submit")
	private WebElement submitform;
	
	
	public String getName() {
		return name.getAttribute("value");
	}


	public void setName(String name) {
		this.name.sendKeys(name);
	}


	public String getPass() {
		return pass.getAttribute("value");
	}


	public void setPass(String pass) {
		this.pass.sendKeys(pass);
	}

	public void submit() {
		submitform.submit();
	}


	
	

}
