package com.cg.jenkins.amazontesting;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		String baseUrl="D:\\RAMA_BDD\\AmazonTesting\\amazon.html";
		System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(baseUrl);
		//Thread.sleep(3600);
		
		
		WebElement uname=driver.findElement(By.name("username"));
		uname.sendKeys("rama");
		WebElement pass=driver.findElement(By.name("password"));
		pass.sendKeys("rama");
		WebElement sub=driver.findElement(By.name("name"));
		sub.click();
		System.out.println("Page title is " +driver.getTitle());
		Thread.sleep(10000);
		try {
			driver.quit();
		}catch(Exception e) {
			System.out.println("Quit");
		}
		
		

}
}
