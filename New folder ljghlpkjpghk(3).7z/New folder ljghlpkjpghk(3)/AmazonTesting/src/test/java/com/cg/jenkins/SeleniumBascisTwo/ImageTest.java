package com.cg.jenkins.SeleniumBascisTwo;



import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageTest {


	WebDriver driver;
	@Before
	public void setUp() throws Exception{
		System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
		driver=new ChromeDriver();
	}
	@After
	public void tearDown() throws Exception{
		driver.quit();
	}
	@Test
	public void size() throws Exception{
		String baseUrl="https://www.google.co.in/";
		driver.get(baseUrl);
			
		Integer counter=0;
        Thread.sleep(2000);
        List<WebElement> listImages=driver.findElements(By.tagName("img"));
        System.out.println("No. of Images: "+listImages.size());
        for(WebElement image:listImages)
        {
            if(image.isDisplayed())
            {
                counter++;
                System.out.println(image.getAttribute("src"));//image.getAttribute("alt")--->gives alternate name of the 
            }
        }
        System.out.println("No. of total displable images: "+counter);

	}

}
