package com.cg.jenkins.pizza;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.cg.driver.DriverUtil;

public class PizzaSeleniumTesting {
	
	private  PizzaSeleniumTesting() {
		
	}
	
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter driver");
		String name=scanner.next();
		
		DriverUtil du=new DriverUtil();
		WebDriver driver=du.intializeDriver(name);
		
		String baseUrl="D:\\RAMA_BDD\\Pizza\\webcontent\\pizza.html";
		driver.get(baseUrl);
		
		WebElement uname=driver.findElement(By.name("username"));
		uname.sendKeys("rama");
		
		driver.findElement(By.id("pizza")).click();
		driver.findElement(By.id("pizza1")).click();
		driver.findElement(By.id("pizza2")).click();
		
		Select obj=new Select(driver.findElement(By.id("sel")));
		obj.selectByValue("Chicken");
		
		driver.findElement(By.name("Extra Cheese")).click();
		driver.findElement(By.name("Vegetarian")).click();
		
		driver.findElement(By.id("delivery")).sendKeys("serve as hot");
		
		
		WebElement sub=driver.findElement(By.name("name"));
		sub.click();
		
		try {
			driver.quit();
		}catch(Exception e) {
			System.out.println("Quit");
		}
		
	}

}
