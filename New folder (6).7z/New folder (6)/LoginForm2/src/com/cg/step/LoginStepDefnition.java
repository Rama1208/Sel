package com.cg.step;

import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cg.pojo.LoginPOMBeans;
import com.cg.util.LoginUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefnition {
	
	private WebDriver driver;
	private LoginPOMBeans pageBean;
	
	@Before
	public void Initialization() {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the drive");
		String name=scanner.next();
		
		LoginUtil du=new LoginUtil();
		driver=du.initializeDriver(name);
		
		pageBean=new LoginPOMBeans();
		PageFactory.initElements(driver, pageBean);
		
		
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
	@Test
	public void test() throws Throwable{
		to_open_web_page();
		fill_the_details();
		page_redirect_to_another_webpage_or_reset();
		Thread.sleep(3000);
		
	}
	

	@Given("^to open web page$")
	public void to_open_web_page() throws Throwable {
	   driver.get("http://localhost:8081/LoginForm2/index.html");
	}

	@When("^fill the details$")
	public void fill_the_details() throws Throwable {
		pageBean.setName("rama");
		Thread.sleep(3000);
		pageBean.setDesign("SE");	
		Thread.sleep(3000);
		Select obj=new Select(driver.findElement(By.id("select")));
		obj.getFirstSelectedOption();
		Thread.sleep(3000);
	}

	@Then("^page redirect to another webpage or reset$")
	public void page_redirect_to_another_webpage_or_reset() throws Throwable {
		pageBean.getLink();
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
		pageBean.getReset();
	}


}
