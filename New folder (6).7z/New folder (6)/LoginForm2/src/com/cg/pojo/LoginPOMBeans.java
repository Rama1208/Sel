package com.cg.pojo;





import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class LoginPOMBeans {

	@FindBy(how=How.ID,id="username")
	private WebElement name;
	
	@FindBy(how=How.NAME,name="field")
	private List<WebElement> design;
	
	@FindBy(how=How.ID,id="select")
	private WebElement country;
	
	@FindBy(how=How.LINK_TEXT,linkText="Next")
	private WebElement link;
	
	@FindBy(how=How.ID,id="reset")
	private WebElement reset;

	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getDesign() {
		String str=null;
		for (WebElement element : design) {
			str=element.getAttribute("value");
		}
		return str;
	}

	public void setDesign(String design) {
		if(design.equals("SE")) {
			this.design.get(0).click();
		}
		else if(design.equals("SSE")) {
			this.design.get(1).click();
		}
	}

	public String getCountry() {
		return new Select(this.country).getFirstSelectedOption().getText();
	}

	public void setCountry(String country) {
		new Select(this.country).selectByVisibleText(country);
	}

	public void getLink() {
		link.click();
	}

	

	public void getReset() {
		reset.click();
	}

	

	
	
}
