package com.cg.hyper;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HyperLinks {
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		String baseUrl="http://localhost:8081/Hyperlinks/hyper.html";
		System.setProperty("webdriver.chrome.driver","Drivers//chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(baseUrl);
		
		driver.findElement(By.partialLinkText("click")).click();
		System.out.println(driver.getTitle());
		driver.navigate().back();
		driver.findElement(By.partialLinkText("w3")).click();
		System.out.println(driver.getTitle());
		
		try {
			Thread.sleep(3000);
		}catch(Exception e) {
			e.getMessage();
		}
		
		
		driver.quit();
		
		
		
	
		
	}



	

}
