package com.cg.step;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pojo.LoginBeans;

import com.cg.util.LoginUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {
	
	private WebDriver driver;
	private LoginBeans pageBean;
	
	@Before
	public void Initialization() {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the drive");
		String name=scanner.next();
		
		LoginUtil du=new LoginUtil();
		driver=du.initializeDriver(name);
		
		pageBean=new LoginBeans();
		PageFactory.initElements(driver, pageBean);
		
		
	}
	

	@After
	public void tearDown() {
		driver.quit();
	}
	
	@Test
	public void test() throws Throwable{
		to_open_web_page();
		all_details_are_filled();
		create_an_account();
		
		
	
	}

	@Given("^to open web page$")
	public void to_open_web_page() throws Throwable {
	   driver.get("https://www.linkedin.com");
	}

	@When("^all details are filled$")
	public void all_details_are_filled() throws Throwable {
		pageBean.setFirstname("rama");
		Thread.sleep(3000);
		pageBean.setLastname("jorrigala");
		Thread.sleep(3000);
		pageBean.setEmail("7702408845");
		Thread.sleep(3000);
		pageBean.setPassword("Ramadevi@123");
		Thread.sleep(3000);
	}

	@Then("^create an account$")
	public void create_an_account() throws Throwable {
		pageBean.getSubmit();
		Thread.sleep(3000);
		String title=driver.getTitle();
		System.out.println(title);
		assertEquals("LinkedIn: Log In or Sign Up", title);
	}

	/*@When("^user clicks on create an account without entering firstname$")
	public void user_clicks_on_create_an_account_without_entering_firstname() throws Throwable {
		pageBean.getSubmit();
		
	}

	@Then("^display firstname can't be blank$")
	public void display_firstname_can_t_be_blank() throws Throwable {
		Alert alert=driver.switchTo().alert();
		  alert.getText();
		  alert.accept();
	}
*/
	/*@When("^user clicks on create an account without entering lastname$")
	public void user_clicks_on_create_an_account_without_entering_lastname() throws Throwable {
		pageBean.getSubmit();
	}

	@Then("^display lastname can't be blank$")
	public void display_lastname_can_t_be_blank() throws Throwable {
	
	}

	@When("^user clicks on create an account without entering email address or phone number$")
	public void user_clicks_on_create_an_account_without_entering_email_address_or_phone_number() throws Throwable {
		pageBean.getSubmit();
	}

	@Then("^display email or phone number can't be blank$")
	public void display_email_or_phone_number_can_t_be_blank() throws Throwable {

	}

	@When("^user clicks on create an account without entering password$")
	public void user_clicks_on_create_an_account_without_entering_password() throws Throwable {
		pageBean.getSubmit();
	}

	@Then("^display password can't be blank$")
	public void display_password_can_t_be_blank() throws Throwable {
	
	}
*/


}
