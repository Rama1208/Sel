package com.cg.test;


import org.junit.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class add {
	
	
	
	@Test
	public  void callMe() throws Throwable {
		i_have_two_numbers();
		i_have_numbers_and_in_step();
		add_these_numbers();
		
	}

	@Given("^I have two numbers$")
	public static void i_have_two_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("Im in given");
	}

	@When("^I have numbers (\\d+) and (\\d+) in step$")
	public static void i_have_numbers_and_in_step() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Im in when");
	}

	@Then("^add these numbers$")
	public static void add_these_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Im in then");
	}
}
