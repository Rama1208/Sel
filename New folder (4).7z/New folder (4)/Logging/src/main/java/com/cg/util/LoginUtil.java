package com.cg.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class LoginUtil {
	
	static WebDriver driver;
	
	public WebDriver initializeDriver(String name) {
	
	if("chrome".equals(name)) {
		
		System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}
		

	return driver;
	}
	
	public static void closeDriver() {
	try {
		driver.quit();
	}catch(Exception e) {
		e.getMessage();
	}	
	
	}
}
		
		
		
	/*}else if("firefox".equals(name)) {
		System.setProperty("webdriver.firefox.driver", "Drivers//firefoxdriver.exe");
		WebDriver driver1=new FirefoxDriver();
		driver1.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver1.manage().window().maximize();
		
		return driver1;
		
	}else if("ie".equals(name)){
		System.setProperty("webdriver.internetexplorer.driver", "Drivers//internetexplorerdriver.exe");
		WebDriver driver2=new InternetExplorerDriver();
		driver2.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver2.manage().window().maximize();
	
		return driver2;
	}
	return null;*/

	


	

