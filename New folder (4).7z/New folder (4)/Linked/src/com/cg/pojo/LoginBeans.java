package com.cg.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginBeans {

	@FindBy(how=How.ID,id="reg-firstname")
	private WebElement firstname;
	
	
	@FindBy(how=How.ID,id="reg-lastname")
	private WebElement lastname;
	
	@FindBy(how=How.ID,id="reg-email")
	private WebElement email;
	
	@FindBy(how=How.ID,id="reg-password")
	private WebElement password;
	
	@FindBy(how=How.ID,id="registration-submit")
	private WebElement submit;

	public String getFirstname() {
		return firstname.getAttribute("value");
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public String getLastname() {
		return lastname.getAttribute("value");
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPassword() {
		return email.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void getSubmit() {
		submit.click();
	}

	
	
	
}
